"""Serialization objects; the same definitions are shown in each training notebook."""
import tensorflow as tf


@tf.keras.utils.register_keras_serializable(package='IncrementalValueComparison')
def factual_bce(y_true, y_pred):
    t = y_true[:, 0]; y = y_true[:, 1]
    observed = (1-t)*y_pred[:, 0]+t*y_pred[:, 1]
    return tf.keras.backend.binary_crossentropy(y, observed)


@tf.keras.utils.register_keras_serializable(package='IncrementalValueComparison')
class LengthMask(tf.keras.layers.Layer):
    def call(self, inputs):
        sequence, lengths = inputs
        return tf.sequence_mask(tf.cast(lengths, tf.int32), maxlen=tf.shape(sequence)[1])
    def compute_output_shape(self, input_shape):
        return input_shape[0][:2]


@tf.keras.utils.register_keras_serializable(package='IncrementalValueComparison')
class ApplyLengthMask(tf.keras.layers.Layer):
    def call(self, inputs):
        sequence, lengths = inputs
        mask = tf.sequence_mask(tf.cast(lengths, tf.int32), maxlen=tf.shape(sequence)[1])
        return tf.where(mask[:, :, None], sequence, tf.zeros_like(sequence))
    def compute_output_shape(self, input_shape):
        return input_shape[0]


@tf.keras.utils.register_keras_serializable(package='IncrementalValueComparison')
class MaskedMean(tf.keras.layers.Layer):
    def call(self, inputs):
        sequence, lengths = inputs
        mask = tf.sequence_mask(tf.cast(lengths, tf.int32), maxlen=tf.shape(sequence)[1])
        clean = tf.where(mask[:, :, None], sequence, tf.zeros_like(sequence))
        return tf.reduce_sum(clean, axis=1)/tf.cast(lengths[:, None], sequence.dtype)
    def compute_output_shape(self, input_shape):
        return (input_shape[0][0], input_shape[0][2])


def load_checkpoint(path):
    objects = {'factual_bce': factual_bce, 'LengthMask': LengthMask,
               'ApplyLengthMask': ApplyLengthMask, 'MaskedMean': MaskedMean}
    objects.update({'IncrementalValueComparison>'+k: v for k, v in list(objects.items())})
    return tf.keras.models.load_model(path, custom_objects=objects)
