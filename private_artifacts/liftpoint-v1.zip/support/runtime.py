"""Bounded batch loading and memory monitoring; model/loss/fit live in notebooks."""
import hashlib
import json
import threading
import time
from pathlib import Path
import numpy as np
import psutil
import tensorflow as tf


class Batches(tf.keras.utils.PyDataset):
    def __init__(self, sequence, static, lengths, labels, indices, model_name, batch_size=64, shuffle=False, seed=42):
        super().__init__(workers=2, use_multiprocessing=False, max_queue_size=2)
        self.sequence = sequence
        self.static = static
        self.lengths = lengths
        self.labels = labels
        self.indices = np.asarray(indices, dtype=np.int64)
        self.order = self.indices.copy()
        self.model_name = model_name
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.seed = seed
        self.epoch = 0
        self._epoch_active = False
        self._set_order()
    def _set_order(self):
        self.order = self.indices.copy()
        if self.shuffle:
            np.random.default_rng(self.seed+self.epoch).shuffle(self.order)
    def __len__(self):
        return (len(self.indices)+self.batch_size-1)//self.batch_size
    def on_epoch_begin(self):
        # Keras starts its enqueuer before this hook. Never mutate order here.
        self._epoch_active = True
    def on_epoch_end(self):
        if self._epoch_active:
            self.epoch += 1
            self._epoch_active = False
            # Keras stops the enqueuer before this hook: safe for next epoch.
            self._set_order()
    def inputs(self, indices):
        if self.model_name == 'mlp':
            return {'customer': self.static[indices]}
        if isinstance(self.sequence, np.memmap):
            # Each worker owns its mapping. Closing it releases resident mappings
            # without touching another prefetch worker or copying the whole file.
            mapping = np.load(self.sequence.filename, mmap_mode='r')
            try:
                values = np.asarray(mapping[indices])
                assert not np.shares_memory(values, mapping)
            finally:
                mapping._mmap.close()
        else:
            values = np.asarray(self.sequence[indices])
        return {'sequence': values,
                'length': self.lengths[indices].astype('int32'), 'customer': self.static[indices]}
    def __getitem__(self, batch):
        take = self.order[batch*self.batch_size:(batch+1)*self.batch_size]
        return self.inputs(take), self.labels[take]


def predict_batches(model, batches):
    # Do not pass the full mmap to TensorFlow. Validation output is only N x 2.
    if not hasattr(model, '_bounded_predict_function'):
        model._bounded_predict_function = tf.function(
            lambda inputs: model(inputs, training=False), reduce_retracing=True)
    predictions = np.empty((len(batches.indices), 2), dtype=np.float32)
    for start in range(0, len(batches.indices), batches.batch_size):
        take = batches.indices[start:start+batches.batch_size]
        predictions[start:start+len(take)] = model._bounded_predict_function(batches.inputs(take)).numpy()
    assert np.isfinite(predictions).all() and ((predictions >= 0) & (predictions <= 1)).all()
    return predictions


def weights_sha256(model):
    h = hashlib.sha256()
    for w in model.get_weights():
        h.update(str(w.shape).encode()); h.update(w.tobytes())
    return h.hexdigest()


class MemoryMonitor:
    """Sample current kernel RSS and system available memory, not GPU/true peak."""
    def __init__(self, interval=.2):
        self.interval = interval; self.samples = []; self.done = threading.Event()
    def start(self):
        self.started = time.perf_counter(); self.process = psutil.Process()
        def sample():
            while not self.done.is_set():
                self.samples.append((time.perf_counter()-self.started, self.process.memory_info().rss,
                                     psutil.virtual_memory().available))
                self.done.wait(self.interval)
        self.thread = threading.Thread(target=sample, daemon=True); self.thread.start()
        return self
    def stop(self):
        self.done.set(); self.thread.join()
        return {'sample_interval_seconds': self.interval, 'samples': len(self.samples),
                'sampled_max_kernel_rss_bytes': max(x[1] for x in self.samples),
                'minimum_available_system_memory_bytes': min(x[2] for x in self.samples),
                'note': 'Sampled RSS includes mmap resident pages, data/framework/kernel. Not guaranteed instantaneous peak. GPU memory not measured.'}


def patience_replay(records, patience):
    best = -np.inf; selected = None; wait = 0; stopped = False
    for row in records:
        if row['uplift_at_30'] > best:
            best = row['uplift_at_30']; selected = row['epoch']; wait = 0
        else:
            wait += 1
        if wait >= patience:
            stopped = True; break
    stop_epoch = row['epoch']
    total = sum(r['epoch_wall_seconds'] for r in records)
    consumed = sum(r['epoch_wall_seconds'] for r in records if r['epoch'] <= stop_epoch)
    return {'patience': patience, 'stop_epoch': stop_epoch, 'stopping_trigger_observed': stopped,
            'selected_epoch': selected, 'uplift_at_30': best, 'consumed_seconds': consumed,
            'saved_seconds_vs_observed': total-consumed,
            'missed_observed_uplift': max(r['uplift_at_30'] for r in records)-best}
